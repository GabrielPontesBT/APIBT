import { Component, Input, HostListener, ChangeDetectionStrategy  } from '@angular/core';
 
@Component({
  selector: 'app-page-header',
  templateUrl: './page-header.component.html',
  styleUrls: ['./page-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PageHeaderComponent {
  @Input() title!: string;
  @Input() newBadgeSrc = 'assets/image/nuevo.svg';
 
  get isNew(): boolean {
    return /-NUEVO\s*$/i.test(this.title || '');
  }
 
  get cleanTitle(): string {
    return (this.title || '').replace(/\s*-NUEVO\s*$/i, '').trim();
  }
 
  isScrolled = false;
 
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    this.isScrolled = scrollTop > 20;
  }
}