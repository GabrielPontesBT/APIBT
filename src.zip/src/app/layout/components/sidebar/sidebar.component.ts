/**
 * sidebar.component.ts
 *
 * Renderiza el árbol de navegación de la documentación, detecta la ruta activa,
 * mantiene siempre abierta la rama del documento actual y permite abrir o cerrar
 * carpetas con política de una sola carpeta abierta por nivel.
 *
 * La animación de apertura/cierre se delega al CSS, y el centrado del nodo
 * espera a que el layout termine de estabilizarse para que el scroll se sienta
 * más natural y fluido.
 */

import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild
} from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { NavigationNode } from '../../../core/models/navigation-node.model';
import { NavigationService } from '../../../features/api-docs/services/navigation.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SidebarComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('sidebarContainer')
  sidebarContainer!: ElementRef<HTMLElement>;

  navigationTree: NavigationNode[] = [];
  activeSlug = '';

  /**
   * Carpetas abiertas manualmente por el usuario.
   */
  expandedFolders = new Set<string>();

  /**
   * Carpetas que forman parte del camino hacia el documento activo.
   */
  activePathSlugs = new Set<string>();

  private destroy$ = new Subject<void>();
  private readonly SIDEBAR_EXPAND_ANIMATION_MS = 420;
  private scrollAnimationFrameId: number | null = null;

  constructor(
    private navigationService: NavigationService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.updateActiveSlug(this.router.url);
    this.loadNavigation();

    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        takeUntil(this.destroy$)
      )
      .subscribe((event) => {
        const navigationEndEvent = event as NavigationEnd;

        this.updateActiveSlug(navigationEndEvent.urlAfterRedirects);
        this.rebuildActivePath();

        this.cdr.markForCheck();
        this.scrollToActiveNode();
      });
  }

  ngAfterViewInit(): void {
    this.scrollToActiveNode();
  }

  ngOnDestroy(): void {
    if (this.scrollAnimationFrameId !== null) {
      cancelAnimationFrame(this.scrollAnimationFrameId);
      this.scrollAnimationFrameId = null;
    }

    this.destroy$.next();
    this.destroy$.complete();
  }

  trackByNode(index: number, node: NavigationNode): string {
    return `${node.type}-${node.slug}`;
  }

  isFolder(node: NavigationNode): boolean {
    return node.type === 'folder';
  }

  isFile(node: NavigationNode): boolean {
    return node.type === 'file';
  }

  hasChildren(node: NavigationNode): boolean {
    return Array.isArray(node.children) && node.children.length > 0;
  }

  isNodeActive(node: NavigationNode): boolean {
    return this.isFile(node) && this.activeSlug === node.slug;
  }

  isFolderInActivePath(node: NavigationNode): boolean {
    return this.isFolder(node) && this.activePathSlugs.has(node.slug);
  }

  isExpanded(node: NavigationNode): boolean {
    if (!this.isFolder(node)) {
      return false;
    } else {
      return this.expandedFolders.has(node.slug) || this.activePathSlugs.has(node.slug);
    }
  }

  getFolderIcon(node: NavigationNode): string {
    return this.isExpanded(node) ? 'expand_more' : 'chevron_right';
  }

  toggleFolder(node: NavigationNode, siblings: NavigationNode[] = []): void {
    if (!this.isFolder(node)) {
      return;
    } else {
      const isManuallyExpanded = this.expandedFolders.has(node.slug);
      const isInActivePath = this.isFolderInActivePath(node);

      if (isManuallyExpanded) {
        if (!isInActivePath) {
          this.collapseBranch(node);
        } else {
          // No cerrar manualmente una rama activa
        }
      } else {
        this.closeSiblingFolders(siblings, node.slug);
        this.expandedFolders.add(node.slug);
      }

      this.cdr.markForCheck();

      const isOpening = !isManuallyExpanded;

      if (isOpening) {
        this.scrollToNodeCenteredAfterLayout(
          node.slug,
          Math.round(this.SIDEBAR_EXPAND_ANIMATION_MS * 0.82)
        );
      } else {
        this.scrollToNodeCenteredAfterLayout(node.slug, 90);
      }
    }
  }

  private loadNavigation(): void {
    this.navigationService.getNavigationTree()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (tree) => {
          this.navigationTree = tree;
          this.rebuildActivePath();
          this.cdr.markForCheck();
          this.scrollToActiveNode();
        },
        error: (error) => {
          console.error('Error cargando sidebar.json', error);
        }
      });
  }

  private updateActiveSlug(url: string): void {
    this.activeSlug = this.normalizeUrlToSlug(url);
  }

  private normalizeUrlToSlug(url: string): string {
    return String(url || '')
      .split('?')[0]
      .split('#')[0]
      .replace(/^\/+/, '')
      .replace(/\/+$/, '');
  }

  private rebuildActivePath(): void {
    this.activePathSlugs.clear();

    const activePath = this.findPathToSlug(this.navigationTree, this.activeSlug);

    activePath.forEach((slug) => {
      this.activePathSlugs.add(slug);
    });

    this.expandedFolders.forEach((slug) => {
      if (this.activePathSlugs.has(slug)) {
        this.expandedFolders.delete(slug);
      } else {
        // No hacer nada
      }
    });
  }

  private findPathToSlug(
    nodes: NavigationNode[],
    targetSlug: string,
    parentPath: string[] = []
  ): string[] {
    for (const node of nodes) {
      if (this.isFile(node)) {
        if (node.slug === targetSlug) {
          return parentPath;
        } else {
          // No hacer nada
        }
      } else {
        const currentPath = [...parentPath, node.slug];
        const result = this.findPathToSlug(node.children || [], targetSlug, currentPath);

        if (result.length > 0) {
          return result;
        } else {
          // No hacer nada
        }
      }
    }

    return [];
  }

  private closeSiblingFolders(siblings: NavigationNode[], currentSlug: string): void {
    siblings.forEach((sibling) => {
      if (!this.isFolder(sibling)) {
        return;
      } else {
        const isCurrent = sibling.slug === currentSlug;
        const isActiveBranch = this.isFolderInActivePath(sibling);

        if (!isCurrent && !isActiveBranch) {
          this.collapseBranch(sibling);
        } else {
          // No hacer nada
        }
      }
    });
  }

  private collapseBranch(node: NavigationNode): void {
    if (this.isFolderInActivePath(node)) {
      return;
    } else {
      this.expandedFolders.delete(node.slug);

      if (this.hasChildren(node)) {
        (node.children || []).forEach((child) => {
          if (this.isFolder(child)) {
            this.collapseBranch(child);
          } else {
            // No hacer nada
          }
        });
      } else {
        // No hacer nada
      }
    }
  }

  private scrollToActiveNode(): void {
    this.runAfterSidebarLayout(120, () => {
      const container = this.sidebarContainer?.nativeElement;

      if (!container) {
        return;
      } else {
        const activeElement = container.querySelector('.sidebar-file.active') as HTMLElement | null;

        if (!activeElement) {
          return;
        } else {
          this.scrollElementToCenter(container, activeElement);
        }
      }
    });
  }

  private scrollToNodeCenteredAfterLayout(slug: string, delay = 0): void {
    this.runAfterSidebarLayout(delay, () => {
      const container = this.sidebarContainer?.nativeElement;

      if (!container) {
        return;
      } else {
        const nodeElement = container.querySelector(`[data-slug="${slug}"]`) as HTMLElement | null;

        if (!nodeElement) {
          return;
        } else {
          this.scrollElementToCenter(container, nodeElement);

          try {
            nodeElement.focus({ preventScroll: true });
          } catch {
            nodeElement.focus();
          }
        }
      }
    });
  }

  private runAfterSidebarLayout(delay: number, callback: () => void): void {
    window.setTimeout(() => {
      if (this.scrollAnimationFrameId !== null) {
        cancelAnimationFrame(this.scrollAnimationFrameId);
      }

      this.scrollAnimationFrameId = requestAnimationFrame(() => {
        this.scrollAnimationFrameId = requestAnimationFrame(() => {
          callback();
          this.scrollAnimationFrameId = null;
        });
      });
    }, delay);
  }

  private scrollElementToCenter(container: HTMLElement, element: HTMLElement): void {
    const containerRect = container.getBoundingClientRect();
    const elementRect = element.getBoundingClientRect();

    const currentScrollTop = container.scrollTop;
    const offsetTopInsideContainer = elementRect.top - containerRect.top + currentScrollTop;
    const targetScrollTop =
      offsetTopInsideContainer - (container.clientHeight / 2) + (element.offsetHeight / 2);

    const maxScrollTop = container.scrollHeight - container.clientHeight;
    const safeTargetScrollTop = Math.max(0, Math.min(targetScrollTop, maxScrollTop));

    container.scrollTo({
      top: safeTargetScrollTop,
      behavior: 'smooth'
    });
  }
}
