---
title: Execute
breadcrumb: false
pageInfo: false
toc: false
contributors: false
editLink: false
lastUpdated: false
prev: false
next: false
comment: false
footer: false
---

<!-- ABRE DATOS DEL MÉTODO -->
::: note Previo al inicio de la ejecución de los servicios de BTS se debe obtener un token válido que luego será utilizado en la ejecución de los servicios.

Para obtener un token valido se debe invocar el servicio Authenticate método Execute.

Se lo invoca pasándole como parámetro de entrada UserId y UserPassword válido con el método de autenticación indicado en la parametrización.

**Nombre publicación:** Authenticate.Execute

**Programa:** BTIAUTHENTICATE

**Global/País:** Global
:::
<!-- CIERRA DATOS DEL MÉTODO -->

<!-- ABRE TABLA DE DATOS -->
::: tabs #Datos 

@tab Datos de Entrada

Nombre | Tipo | Comentarios
:--------- | :--------- | :---------
UserId | String | Usuario de autenticación.
UserPassword | String | Contraseña de autenticación.

@tab Datos de Salida

Nombre | Tipo | Comentarios
:--------- | :--------- | :---------
SessionToken | String | Token a utilizar para la ejecución de servicios.

@tab Errores

Código | Descripción
:--------- | :---------
50 | Error de Autenticación. 

El mensaje de error puede variar ya que es devuelto por el programa que valida usuario/contraseña, y dicho programa es parametrizable (se puede utilizar el que viene por defecto u otro).
::: 
<!-- CIERRA TABLA DE DATOS -->

<!-- ABRE EJEMPLO DE INVOCACIÓN -->
::: warning Ejemplo de Invocación
::: code-tabs #Formato

@tab XML
```xml
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:bts="http://uy.com.dlya.bantotal/BTSOA/">
   <soapenv:Header/>
   <soapenv:Body>
      <bts:Authenticate.Execute>
         <bts:Btinreq>
            <bts:Device>AV</bts:Device>
            <bts:Usuario>MINSTALADOR</bts:Usuario>
            <bts:Requerimiento></bts:Requerimiento>
            <bts:Canal>BTDIGITAL</bts:Canal>
            <bts:Token></bts:Token>
         </bts:Btinreq>
         <bts:UserId>MINSTALADOR</bts:UserId>
         <bts:UserPassword>Bantotal2015</bts:UserPassword>
      </bts:Authenticate.Execute>
   </soapenv:Body>
</soapenv:Envelope>
```

@tab JSON
```json
{
	"Btinreq": {
		"Device": "AV",
		"Usuario": "MINSTALADOR",
		"Requerimiento": 1,
		"Canal": "BTDIGITAL",
		"Token": "fa2c02c95a4A8B5C60A82434"
	},
	"UserId": "BANTOTAL",
  "UserPassword": "z0na#1357"
}'
```
:::
<!-- CIERRA EJEMPLO DE INVOCACIÓN -->

<!-- ABRE EJEMPLO DE RESPUESTA -->
::: warning Ejemplo de Respuesta
::: code-tabs #Formato

@tab XML
```xml
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:SOAP-ENC="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   <SOAP-ENV:Body>
      <Authenticate.ExecuteResponse xmlns="http://uy.com.dlya.bantotal/BTSOA/">
         <Btinreq>
            <Device>AV</Device>
            <Usuario>MINSTALADOR</Usuario>
            <Requerimiento/>
            <Canal>BTDIGITAL</Canal>
            <Token/>
         </Btinreq>
         <SessionToken>7f582501004A8B5C60A82434</SessionToken>
         <Erroresnegocio></Erroresnegocio>
         <Btoutreq>
            <Numero>722</Numero>
            <Estado>OK</Estado>
            <Servicio>Authenticate.Execute</Servicio>
            <Fecha>2017-11-24</Fecha>
            <Requerimiento/>
            <Hora>12:52:24</Hora>
            <Canal>BTDIGITAL</Canal>
         </Btoutreq>
      </Authenticate.ExecuteResponse>
   </SOAP-ENV:Body>
</SOAP-ENV:Envelope>
```

@tab JSON
```json
'{
	"Btinreq": {
		"Device": "AV",
		"Usuario": "MINSTALADOR",
		"Requerimiento": 1,
		"Canal": "BTDIGITAL",
		"Token": "fa2c02c95a4A8B5C60A82434"
	},
    "SessionToken": "991ba47aac4A8B5C60A82434",
    "Erroresnegocio": {
        "BTErrorNegocio": []
    },
    "Btoutreq": {
        "Numero": 46,
        "Servicio": "Authenticate.Execute",
        "Estado": "OK",
        "Fecha": "2019-10-24",
        "Requerimiento": 1,
        "Hora": "20:55:06",
        "Canal": "BTDIGITAL"
    }
}'
```
:::
<!-- CIERRA EJEMPLO DE RESPUESTA -->
